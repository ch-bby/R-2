#!/usr/bin/env python3
""" ME 499 Computer Programming for Mechanical Systems
    Lab 0 Part 2: Hello World
    Samuel J. Stumbo
    5 April 2018

    This script prints "Hello World" to the command line."""
print('Hello, World!')
