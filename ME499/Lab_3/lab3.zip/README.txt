
*************************
      ME 499 
       Lab 3
    3 May 2018
By: Samuel J. Stumbo
*************************

Files and Libraries necessary to run:
*************************************
Main file = lab3.py

runs:
*****
msd.py
rnd_sum__hist.py
sine_wave_plot.py
smd.py
time_sort.py

Libraries:
**********
matplotlib.pyplot as plt
numpy as np
math.pi
time


