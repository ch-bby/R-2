This is not complete.

I was not able to converge on solutions for the last 4 parts...

Had trouble figuring out the indexing. 

You'll need:

csv and numpy to run this code. 



I think that's it...

Can I have a redo?!