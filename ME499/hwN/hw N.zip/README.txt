***********************
ME 499 HW N
@author: Samuel J. Stumbo
date: 4 June 2018
problems attempted: [1, 2, 3, 4, 5]
***********************
files:
***********************
1: is_pow.py
2: mysqrt.py
3. pi_mc.py
4. prob_1lt2.py
5. polygon.py